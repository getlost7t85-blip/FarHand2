# RemoteSupport signaling server

```
npm install
npm start        # ws://0.0.0.0:8080/ws
```

## Protocol

Connect: `wss://host:port/ws?role=host|controller&code=123456`

- `code` must be exactly 6 digits. The **host** app generates it and shows
  it on screen; the person using the host device reads it out (or shares it
  via chat/call) to whoever will control the device. That hand-off is the
  actual authorization step — same model as RustDesk/AnyDesk/TeamViewer.
- Only one `host` and one `controller` may hold a given code at a time; a
  duplicate role for the same code is rejected, not silently swapped in.
- Once both sides are present, each receives `{"type":"peer-joined"}` — the
  client should wait for this before sending a WebRTC offer.
- After that, every JSON message one side sends is relayed byte-for-byte to
  the other. The server never parses `offer`/`answer`/`ice-candidate`/`input`
  payloads; it only reads `role` and `code` from the query string.
- Pairing codes expire after 2 minutes if never matched, and rate-limiting
  caps pairing attempts per IP per minute.

## Production checklist

- Put this behind TLS (`wss://`) — terminate at a reverse proxy (nginx,
  Caddy) or run Node's `https` server with a cert.
- Consider a TURN server (e.g. coturn) in addition to the public STUN
  server the apps use by default, for peers behind symmetric NATs.
- This process holds no persistent data — it's safe to run multiple
  instances behind a load balancer only if sticky-sessioned by `code`
  (a given pairing's two sockets must land on the same instance), or by
  swapping the in-memory `sessions` map for a shared store (Redis pub/sub)
  if you need to scale beyond one instance.
