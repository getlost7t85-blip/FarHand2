// Minimal signaling/matchmaking server for RemoteSupport.
//
// Responsibilities (and nothing more):
//  1. A "host" connects and registers a pairing code.
//  2. A "controller" connects with that same code.
//  3. Once both sides of a code are present, the server relays whatever
//     JSON messages they send each other verbatim (offer/answer/ICE
//     candidates, plus any app-level control messages).
//  4. Actual screen video and input events never touch this server — they
//     flow peer-to-peer over the WebRTC connection these messages set up.
//
// Run:
//   npm install
//   node index.js            # listens on ws://0.0.0.0:8080
//
// Put this behind TLS (wss://) in production — e.g. an nginx reverse proxy
// terminating TLS and forwarding to this process, or a Node https server.

const { WebSocketServer } = require('ws');
const { randomInt } = require('crypto');
const http = require('http');
const url = require('url');

const PORT = process.env.PORT || 8080;
const CODE_TTL_MS = 2 * 60 * 1000; // pairing codes expire if unmatched
const MAX_CODE_ATTEMPTS_PER_MINUTE = 20; // basic guess-rate limiting

/** @type {Map<string, { host: WebSocket|null, controller: WebSocket|null, createdAt: number }>} */
const sessions = new Map();

/** @type {Map<string, number[]>} ip -> timestamps of recent pairing attempts */
const attemptLog = new Map();

function isRateLimited(ip) {
  const now = Date.now();
  const windowStart = now - 60_000;
  const attempts = (attemptLog.get(ip) || []).filter((t) => t > windowStart);
  attempts.push(now);
  attemptLog.set(ip, attempts);
  return attempts.length > MAX_CODE_ATTEMPTS_PER_MINUTE;
}

function cleanupExpiredSessions() {
  const now = Date.now();
  for (const [code, session] of sessions.entries()) {
    const bothMissing = !session.host && !session.controller;
    const expired = now - session.createdAt > CODE_TTL_MS;
    if (bothMissing || (expired && !(session.host && session.controller))) {
      sessions.delete(code);
    }
  }
}
setInterval(cleanupExpiredSessions, 30_000);

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('RemoteSupport signaling server is running.\n');
});

const wss = new WebSocketServer({ server, path: '/ws' });

wss.on('connection', (ws, req) => {
  const { query } = url.parse(req.url, true);
  const role = query.role; // "host" | "controller"
  const code = String(query.code || '').trim();
  const ip = req.socket.remoteAddress;

  if (!['host', 'controller'].includes(role) || !/^\d{6}$/.test(code)) {
    ws.close(4000, 'Invalid role or code');
    return;
  }

  if (isRateLimited(ip)) {
    ws.close(4001, 'Rate limited');
    return;
  }

  let session = sessions.get(code);
  if (!session) {
    session = { host: null, controller: null, createdAt: Date.now() };
    sessions.set(code, session);
  }

  if (session[role]) {
    // A second socket for the same role/code — reject rather than silently
    // replace, so an attacker can't hijack an in-progress session by
    // guessing/racing a code.
    ws.close(4002, `A ${role} is already connected for this code`);
    return;
  }

  session[role] = ws;
  console.log(`[+] ${role} joined session ${code}`);

  ws.on('message', (data) => {
    const peer = role === 'host' ? session.controller : session.host;
    if (peer && peer.readyState === peer.OPEN) {
      peer.send(data.toString());
    }
    // If the peer hasn't joined yet, the message is dropped. Clients should
    // wait for their own "peer-joined" notice (see below) before sending
    // offers, so this path is mainly a safety net.
  });

  const otherRole = role === 'host' ? 'controller' : 'host';
  if (session[otherRole]) {
    session.host?.send(JSON.stringify({ type: 'peer-joined' }));
    session.controller?.send(JSON.stringify({ type: 'peer-joined' }));
  }

  ws.on('close', () => {
    console.log(`[-] ${role} left session ${code}`);
    session[role] = null;
    const other = session[otherRole];
    if (other && other.readyState === other.OPEN) {
      other.send(JSON.stringify({ type: 'peer-left' }));
    }
    if (!session.host && !session.controller) {
      sessions.delete(code);
    }
  });

  ws.on('error', (err) => {
    console.error(`[!] socket error (${role}, ${code}):`, err.message);
  });
});

server.listen(PORT, () => {
  console.log(`RemoteSupport signaling server listening on :${PORT}`);
});
