# FarHand (Android)

A consent-based remote-support app, architecturally similar to RustDesk: one
APK, two roles picked at runtime. "Be controlled" turns a device into the
*host* (the one being helped); "Control another device" turns it into the
*controller/viewer*, which connects using the host's pairing code to view
its screen and send input, over WebRTC, through the signaling server in
`/server`.

## Building an APK without Android Studio (GitHub Actions)

This repo builds entirely through GitHub Actions — push it to a GitHub repo
and you get an APK back without installing Android Studio or an SDK
anywhere yourself. Two workflows, both in `.github/workflows/`:

### 1. Debug APK — every push, no setup required

`build-debug-apk.yml` runs automatically on every push to `main` (and on
pull requests, and on demand via "Run workflow" in the Actions tab). It
needs no secrets. When it finishes:

1. Go to the repo's **Actions** tab → open the run → scroll to **Artifacts**.
2. Download `farhand-debug-apk` (a zip containing the `.apk`).
3. Transfer it to an Android device and install it (you'll need to allow
   "install unknown apps" for whatever app you use to open it — Files,
   browser downloads, etc.).

This APK is signed with Android's auto-generated debug key, which is fine
for installing on your own devices but not for distributing to others or
publishing anywhere.

### 2. Signed release APK — on a version tag

`release-apk.yml` runs when you push a tag like `v1.0.0`, and produces a
properly signed release APK attached to a new **GitHub Release** — a
permanent, shareable download link, no "Artifacts" digging required.

**One-time setup**, from any machine with a JDK (not Android Studio — just
a JDK; GitHub Codespaces or your own Linux/Mac/WSL works fine):

```bash
keytool -genkeypair -v -keystore release.keystore -alias farhand \
  -keyalg RSA -keysize 2048 -validity 10000
```

It'll ask for a keystore password and a key password (can be the same) and
some identity questions — answer those freely, they end up in the
certificate, not anywhere user-visible. Then, in your GitHub repo, go to
**Settings → Secrets and variables → Actions → New repository secret** and
add four secrets:

| Secret name | Value |
|---|---|
| `RELEASE_KEYSTORE_BASE64` | `base64 -w0 release.keystore` (the output, as one line) |
| `RELEASE_KEYSTORE_PASSWORD` | the keystore password you chose |
| `RELEASE_KEY_ALIAS` | `farhand` (or whatever `-alias` you used) |
| `RELEASE_KEY_PASSWORD` | the key password you chose |

Then **delete `release.keystore` from your local machine** (or store it
somewhere safe outside the repo) — it should never be committed; `.gitignore`
already excludes it. **Keep a backup of the keystore and its passwords
somewhere safe** (a password manager): if you lose it, you can't publish an
update under the same app identity ever again — you'd have to ship under a
new package name.

To cut a release:

```bash
git tag v1.0.0
git push origin v1.0.0
```

The workflow builds, signs, and attaches `app-release.apk` to a new release
at `github.com/<you>/<repo>/releases`.

### Why `gradle` and not `./gradlew`

Both workflows call `gradle` directly (via `gradle/actions/setup-gradle`,
which installs the exact pinned Gradle version on the runner) rather than
a committed `gradlew` wrapper. A committed wrapper is the normal Android
convention, but generating its binary launcher jar requires a local Gradle
install to run `gradle wrapper` once — if you'd rather have one (e.g. to
also build locally without installing Gradle yourself), run that command
once from any machine with Gradle installed and commit the resulting
`gradlew`, `gradlew.bat`, and `gradle/wrapper/` files; the workflows will
keep working either way.

## Why it looks the way it does

You asked for a version that hides the fact that a session is active. That
isn't something this build does, for two reasons:

1. **It's not legally/technically avoidable on the host side.** Starting
   Android 10, any app that captures the screen (`MediaProjection`) or
   receives synthetic input (`AccessibilityService`) must run as a
   foreground service with an ongoing, non-dismissable notification, and
   screen capture also shows a system status-bar icon. These are enforced
   by the OS itself — no manifest flag, API, or notification trick removes
   them on a stock, non-rooted device. Apps that try to work around this
   (e.g. by abusing notification channels, or targeting old API levels to
   dodge the restriction) get removed from Play and, more importantly, are
   functionally spyware.
2. **That's also the actual safety mechanism.** The indicator exists so the
   device owner always knows when someone else can see/control their
   screen. Removing it is what turns a support tool into stalkerware.

What this build *does* do: keeps those required indicators, but makes the
*rest* of the UX close to RustDesk — a pairing code, one-tap session start,
a permission screen, a clean floating "session active" pill you (the host)
can tap to end the session instantly, and a working signaling + WebRTC
layer underneath.

## Architecture

```
Controller app  <--WebRTC video + DataChannel-->  Host app
      \                                                /
       \--- wss://.../ws?role=controller&code=123456 -/
        \-- wss://.../ws?role=host&code=123456 ------/
                  (both via the server in /server)
```

The signaling server only ever relays `offer` / `answer` / `ice-candidate`
JSON between the two sockets sharing a code (see `server/README.md`). Once
the WebRTC connection is up, video and input flow peer-to-peer and never
touch the server again.

- `ScreenCaptureService` — foreground service; uses `MediaProjection` +
  `org.webrtc.ScreenCapturerAndroid` to turn the screen into a WebRTC video
  track, creates the offer once a controller joins, and relays incoming
  `DataChannel` input events to `RemoteAccessibilityService`. Required
  notification + Android's system "screen being recorded" icon are both
  present (`service/ScreenCaptureService.kt`).
- `RemoteAccessibilityService` — `AccessibilityService` that turns incoming
  tap/swipe events into `dispatchGesture()` / `GLOBAL_ACTION_*` calls.
  Required notification is present (`service/RemoteAccessibilityService.kt`).
- `ControllerActivity` — renders the host's video track into a
  `SurfaceViewRenderer` and sends touches back over the `DataChannel`
  (`ui/ControllerActivity.kt`).
- `WebRtcClient` — shared peer-connection wrapper: creates/configures the
  `PeerConnection`, the local video track (host) or remote track callback
  (controller), and the `input` `DataChannel` both sides use
  (`network/WebRtcClient.kt`).
- `SignalingClient` — WebSocket client implementing the `/server` protocol:
  connect with role+code, wait for `peer-joined`, exchange SDP/ICE as JSON
  (`network/SignalingClient.kt`).
- `SessionPillOverlay` — a small `TYPE_APPLICATION_OVERLAY` pill (needs
  "Display over other apps") showing "Session active — tap to end", so the
  host has an *extra*, friendlier way to kill the session beyond swiping
  the system notification. This is additive, not a replacement for the
  required notification.

## Permissions this app requests (and why)

| Permission | Why |
|---|---|
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Required to keep capture alive while backgrounded |
| `SYSTEM_ALERT_WINDOW` | Draws the optional "end session" pill |
| `BIND_ACCESSIBILITY_SERVICE` | Lets the controller send input |
| `INTERNET` | Talk to the signaling server and WebRTC peer |

## Signaling server

A working Node.js implementation is in `/server` (not a stub) — see
`server/README.md` to run it. Point `AppConfig.SIGNALING_URL` at your
deployed `wss://` endpoint before building (one place now — see
`network/AppConfig.kt`).

## Configuration

All deployment-specific values live in one file,
`network/AppConfig.kt`:

```kotlin
object AppConfig {
    const val SIGNALING_URL = "wss://your-signaling-server.example/ws"
    val turnConfig = TurnConfig(url = "", username = "", password = "")
}
```

Fill in `turnConfig.url` with a TURN server (e.g. self-hosted coturn) if
your users will be behind symmetric NATs/firewalls where STUN alone can't
establish a direct path; leave it blank to use STUN only.

## What's implemented

- **Fixed a dependency that wouldn't actually resolve:** earlier versions of
  this project depended on `org.webrtc:google-webrtc:1.0.+`, which was
  published to JCenter — shut down since 2021. `app/build.gradle.kts` now
  uses `io.github.webrtc-sdk:android` (same `org.webrtc.*` classes, actively
  published to Maven Central), so a clean build — including the CI
  workflows above — actually succeeds.
- **Fixed a CI action that failed on a fresh SDK install:** both workflows
  used to set up the Android SDK via `android-actions/setup-android@v3`,
  which tries to install Google's legacy `tools` package — removed from the
  SDK repository years ago, so the action fails immediately. Both workflows
  now install the SDK command-line tools directly from Google's own
  download server instead.
- Screen capture → WebRTC video track (host), rendered live on the
  controller via `SurfaceViewRenderer`.
- Input (tap **and swipe**, distinguished by drag distance in
  `ControllerActivity.handleTouch`) sent controller → host over the
  `DataChannel` and replayed via `RemoteAccessibilityService`.
- The host reports its **real screen size** to the controller right after
  the `DataChannel` opens (`WebRtcClient.sendScreenSize` /
  `ScreenCaptureService`'s `onDataChannelOpen`), so touch-coordinate mapping
  isn't a guess.
- Optional **TURN** support, configured in one place (`AppConfig`).
- Basic **reconnect**: an unexpected signaling-socket drop retries up to 3
  times with a fixed backoff before surfacing an error; an intentional
  `disconnect()` never retries (`SignalingClient`).
- A generated **adaptive launcher icon** (original glyph, no third-party
  IP) so the project builds as-is without missing-resource errors.

## Branding

- **Name:** FarHand — "a hand that reaches far," i.e. controlling a screen
  that isn't in front of you.
- **Color theme:** deep indigo primary (`#2D3A8C`) with a mint/teal accent
  (`#22D3B6`) used for anything "live" (the session pill's border, the
  accent color), defined once in `values/colors.xml` and wired into
  `values/themes.xml` (`Theme.FarHand`) so it actually drives the app's
  UI — not just the launcher icon.
- **Icon:** an original geometric mark — a white device bezel with a mint
  display and a cursor reaching into it — on an indigo background
  (`drawable/ic_launcher_foreground.xml` + adaptive icon in
  `mipmap-anydpi-v26/`). No third-party logos or characters.
- **Package / application ID:** `com.yapper.farhand` (changed from the
  placeholder `com.example.remotesupport` — source directories, every
  `package`/`import` line, and `namespace`/`applicationId` in
  `app/build.gradle.kts` are all updated to match).
- The `Application` subclass is `FarHandApp` (`FarHandApp.kt`), referenced
  from `AndroidManifest.xml`'s `android:name` and from
  `ScreenCaptureService.kt`'s notification-channel constants.

## Still out of scope

- Anything to do with suppressing Android's own capture/accessibility
  indicators — see "Why it looks the way it does" above.
- Text-input forwarding (only tap/swipe/global-action are wired up).
- Deeper UI polish (styling, animations, dark mode) beyond a functional
  Material baseline.

## Project layout

```
app/src/main/java/com/yapper/farhand/
  MainActivity.kt                        role picker: be controlled / control a device
  ui/HostActivity.kt                     host flow: pairing code, permissions, start sharing
  ui/ControllerActivity.kt               controller flow: enter code, view + touch remote screen
  service/ScreenCaptureService.kt        MediaProjection -> WebRTC video track (host)
  service/RemoteAccessibilityService.kt  input injection (host)
  ui/SessionPillOverlay.kt               optional floating "end session" control (host)
  network/AppConfig.kt                   signaling URL + TURN config, in one place
  network/WebRtcClient.kt                shared PeerConnection/DataChannel wrapper
  network/SignalingClient.kt             WebSocket signaling client, with reconnect (both roles)
server/
  index.js, package.json, README.md      the signaling server itself
.github/workflows/
  build-debug-apk.yml                    CI: debug APK on every push (no secrets)
  release-apk.yml                        CI: signed release APK on a version tag
```

A device can run only one role at a time per session, but the same install
can switch roles between sessions — same as RustDesk's single-APK model.
