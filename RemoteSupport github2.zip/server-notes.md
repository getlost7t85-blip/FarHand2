# Signaling server

Superseded by the actual implementation in `/server` — see `server/README.md`
for the protocol and run instructions, `server/index.js` for the code.
