plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yapper.farhand"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yapper.farhand"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Release signing is configured from environment variables so CI can
    // sign the APK without a keystore ever being committed to the repo.
    // See .github/workflows/release-apk.yml and README.md ("Releasing").
    val releaseKeystorePath = System.getenv("RELEASE_KEYSTORE_PATH")
    val hasReleaseSigning = !releaseKeystorePath.isNullOrBlank()

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseKeystorePath!!)
                storePassword = System.getenv("RELEASE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("RELEASE_KEY_ALIAS")
                keyPassword = System.getenv("RELEASE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
            // Without the env vars above (e.g. a plain `assembleRelease` run
            // outside CI), this build type is left unsigned rather than
            // failing the build — see README.md for how to sign locally too.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // WebRTC for peer-to-peer video + data channel (screen stream, input
    // events). NOTE: the old "org.webrtc:google-webrtc:1.0.+" coordinate
    // you may see in older tutorials was published to JCenter, which has
    // been shut down since 2021 — it will not resolve on a fresh build.
    // This is the actively maintained Maven Central replacement (same
    // org.webrtc.* classes, so no source changes needed).
    implementation("io.github.webrtc-sdk:android:150.7871.04")

    // Lightweight WebSocket client for signaling
    implementation("org.java-websocket:Java-WebSocket:1.5.6")

    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
}
