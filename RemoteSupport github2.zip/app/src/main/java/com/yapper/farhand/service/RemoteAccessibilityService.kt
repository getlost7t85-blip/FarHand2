package com.yapper.farhand.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Turns input events received from the paired controller into real gestures
 * on this device. Android automatically shows its own persistent
 * notification ("RemoteSupport is active") whenever an enabled
 * AccessibilityService is running with gesture/content capabilities — that
 * notification is managed by the OS, not by this class, and this app does
 * not attempt to dismiss or pre-empt it.
 */
class RemoteAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used for input injection; left for optional future features
        // (e.g. read-only screen-reader-style context for the controller).
    }

    override fun onInterrupt() {}

    fun performTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun performSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun performGlobalBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    companion object {
        // Set by the system once the service is bound/running, so other
        // components (e.g. the signaling callback) can route input calls
        // into it without a manual bind.
        var instance: RemoteAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
