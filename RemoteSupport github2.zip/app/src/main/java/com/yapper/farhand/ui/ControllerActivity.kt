package com.yapper.farhand.ui

import android.os.Bundle
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.yapper.farhand.R
import com.yapper.farhand.network.AppConfig
import com.yapper.farhand.network.RemoteInputEvent
import com.yapper.farhand.network.SignalingClient
import com.yapper.farhand.network.WebRtcClient
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.RendererCommon
import org.webrtc.SessionDescription
import org.webrtc.VideoTrack
import kotlin.math.abs

/**
 * Controller/viewer side: enters the host's pairing code, connects to the
 * signaling server as "controller", renders the incoming WebRTC video track
 * into a SurfaceViewRenderer, and turns touches on that surface into
 * RemoteInputEvents sent back to the host over the WebRTC DataChannel the
 * host created.
 */
class ControllerActivity : AppCompatActivity() {

    private lateinit var eglBase: EglBase
    private var signalingClient: SignalingClient? = null
    private var webRtcClient: WebRtcClient? = null
    private var connected = false
    private var remoteTrack: VideoTrack? = null

    // Updated from the host's "screen-size" DataChannel message once the
    // session is up; these defaults are only used for the brief window
    // before that message arrives.
    private var remoteWidth = 1080f
    private var remoteHeight = 2400f

    // Drag-tracking state for distinguishing a tap from a swipe.
    private var downX = 0f
    private var downY = 0f
    private val tapSlopPx = 24f // local-view pixels; below this, treat as a tap not a swipe

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_controller)
        eglBase = EglBase.create()

        val codeInput = findViewById<android.widget.EditText>(R.id.etSessionCode)
        val connectButton = findViewById<android.widget.Button>(R.id.btnConnect)
        val remoteRenderer = findViewById<org.webrtc.SurfaceViewRenderer>(R.id.remoteRenderer)

        remoteRenderer.init(eglBase.eglBaseContext, null)
        remoteRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)

        connectButton.setOnClickListener {
            val code = codeInput.text.toString().trim()
            if (code.length != 6) {
                Toast.makeText(this, "Enter the 6-digit code shown on the host device", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            connect(code, remoteRenderer)
        }

        remoteRenderer.setOnTouchListener { view, event ->
            if (!connected) return@setOnTouchListener false
            handleTouch(view.width, view.height, event)
            true
        }
    }

    private fun connect(code: String, remoteRenderer: org.webrtc.SurfaceViewRenderer) {
        webRtcClient = WebRtcClient(
            context = this,
            isHost = false,
            eglBase = eglBase,
            turnConfig = AppConfig.turnConfig,
            onRemoteVideoTrack = { track ->
                remoteTrack = track
                runOnUiThread { track.addSink(remoteRenderer) }
            },
            onScreenSize = { width, height ->
                if (width > 0 && height > 0) {
                    remoteWidth = width.toFloat()
                    remoteHeight = height.toFloat()
                }
            },
            onLocalIceCandidate = { candidate -> signalingClient?.sendIceCandidate(candidate) }
        )

        signalingClient = SignalingClient(AppConfig.SIGNALING_URL, object : SignalingClient.Listener {
            override fun onPeerJoined() {
                // Host is present; wait for its offer (host initiates).
            }
            override fun onRemoteOffer(sdp: SessionDescription) {
                webRtcClient?.createPeerConnection()
                webRtcClient?.setRemoteDescription(sdp)
                webRtcClient?.createAnswer { answer -> signalingClient?.sendAnswer(answer) }
                connected = true
            }
            override fun onRemoteIceCandidate(candidate: IceCandidate) {
                webRtcClient?.addIceCandidate(candidate)
            }
            override fun onConnectionError(message: String) {
                runOnUiThread { Toast.makeText(this@ControllerActivity, message, Toast.LENGTH_SHORT).show() }
            }
        })
        signalingClient?.connect(role = "controller", code = code)
        Toast.makeText(this, "Connecting to $code…", Toast.LENGTH_SHORT).show()
    }

    /**
     * Maps local view coordinates to the host's real screen coordinates
     * (via remoteWidth/remoteHeight, reported by the host) and distinguishes
     * a tap from a swipe by total drag distance, sending exactly one
     * RemoteInputEvent per gesture on ACTION_UP.
     */
    private fun handleTouch(viewWidth: Int, viewHeight: Int, event: MotionEvent) {
        fun mapX(x: Float) = (x / viewWidth) * remoteWidth
        fun mapY(y: Float) = (y / viewHeight) * remoteHeight

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - downX
                val dy = event.y - downY
                val client = webRtcClient ?: return
                if (abs(dx) < tapSlopPx && abs(dy) < tapSlopPx) {
                    client.sendInput(RemoteInputEvent(type = "tap", x1 = mapX(downX), y1 = mapY(downY)))
                } else {
                    client.sendInput(
                        RemoteInputEvent(
                            type = "swipe",
                            x1 = mapX(downX), y1 = mapY(downY),
                            x2 = mapX(event.x), y2 = mapY(event.y)
                        )
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        remoteTrack?.removeSink(findViewById(R.id.remoteRenderer))
        webRtcClient?.close()
        signalingClient?.disconnect()
        findViewById<org.webrtc.SurfaceViewRenderer>(R.id.remoteRenderer).release()
        eglBase.release()
        super.onDestroy()
    }
}
