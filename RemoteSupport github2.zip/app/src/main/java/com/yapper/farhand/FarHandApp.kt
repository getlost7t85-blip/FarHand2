package com.yapper.farhand

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class FarHandApp : Application() {

    companion object {
        const val CAPTURE_CHANNEL_ID = "capture_channel"
        const val ACCESSIBILITY_CHANNEL_ID = "accessibility_channel"
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            // One channel per required foreground notification. Both default
            // to HIGH importance deliberately: these notifications exist to
            // inform the device owner a session is live, so they should not
            // be silently minimized or hidden by a low-importance channel.
            nm.createNotificationChannel(
                NotificationChannel(
                    CAPTURE_CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_HIGH
                )
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    ACCESSIBILITY_CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_HIGH
                )
            )
        }
    }
}
