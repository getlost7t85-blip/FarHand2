package com.yapper.farhand

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.yapper.farhand.ui.ControllerActivity
import com.yapper.farhand.ui.HostActivity

/**
 * Single-APK role picker, same pattern RustDesk itself uses: one app, two
 * roles chosen at runtime — "be controlled" (host) or "control another
 * device" (controller/viewer). Each role's permissions and services are
 * fully independent, so a device only ever asks for what that role needs.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_role_picker)

        findViewById<android.widget.Button>(R.id.btnBeControlled).setOnClickListener {
            startActivity(Intent(this, HostActivity::class.java))
        }

        findViewById<android.widget.Button>(R.id.btnControlDevice).setOnClickListener {
            startActivity(Intent(this, ControllerActivity::class.java))
        }
    }
}
