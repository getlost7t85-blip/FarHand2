package com.yapper.farhand.network

/**
 * Single place to point the app at your own deployed signaling server and
 * (optionally) a TURN server. Fill these in before building a release.
 */
object AppConfig {
    const val SIGNALING_URL = "wss://your-signaling-server.example/ws"

    // Leave TURN_URL blank to skip TURN and use STUN only (fine on most
    // home/office networks, not guaranteed behind symmetric NATs/firewalls).
    val turnConfig = TurnConfig(
        url = "",           // e.g. "turn:your-turn-server.example:3478"
        username = "",
        password = ""
    )
}
