package com.yapper.farhand.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.yapper.farhand.FarHandApp
import com.yapper.farhand.R
import com.yapper.farhand.network.AppConfig
import com.yapper.farhand.network.SignalingClient
import com.yapper.farhand.network.WebRtcClient
import com.yapper.farhand.ui.HostActivity
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource

/**
 * Foreground service that owns the MediaProjection-backed screen capture
 * and streams it to the paired controller over WebRTC.
 *
 * Uses org.webrtc.ScreenCapturerAndroid (shipped in the WebRTC Android SDK)
 * instead of a hand-rolled VirtualDisplay/MediaCodec pipeline — it already
 * implements VideoCapturer against MediaProjection correctly.
 *
 * Android requirements this deliberately does NOT try to work around:
 *  - Must be a foreground service with an ongoing notification the whole
 *    time MediaProjection is active (enforced by the OS, not just policy).
 *  - The system shows its own "screen is being recorded/shared" icon in
 *    the status bar for as long as capture is active; that's drawn by the
 *    platform, not this app, and there's no API to hide it.
 */
class ScreenCaptureService : Service() {

    private lateinit var eglBase: EglBase
    private lateinit var webRtcClient: WebRtcClient
    private lateinit var signalingClient: SignalingClient
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var screenWidth = 0
    private var screenHeight = 0

    // Stashed so startCapture() (called from the onPeerJoined signaling
    // callback, which fires later and off this method's call stack) can
    // reach the MediaProjection result data passed into onStartCommand.
    private var currentResultData: Intent? = null

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_RESULT_DATA = "result_data"
        private const val EXTRA_SESSION_CODE = "session_code"

        fun newIntent(context: Context, resultCode: Int, resultData: Intent, sessionCode: String): Intent =
            Intent(context, ScreenCaptureService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, resultData)
                putExtra(EXTRA_SESSION_CODE, sessionCode)
            }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: return START_NOT_STICKY
        val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA) ?: return START_NOT_STICKY
        val sessionCode = intent.getStringExtra(EXTRA_SESSION_CODE) ?: ""
        currentResultData = resultData
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels

        // Required: start the foreground notification BEFORE touching
        // MediaProjection APIs, and keep it up for the service's lifetime.
        startForeground(NOTIFICATION_ID, buildNotification())

        eglBase = EglBase.create()
        webRtcClient = WebRtcClient(
            context = this,
            isHost = true,
            eglBase = eglBase,
            turnConfig = AppConfig.turnConfig,
            onInputEvent = { event -> dispatchToAccessibilityService(event) },
            onLocalIceCandidate = { candidate -> signalingClient.sendIceCandidate(candidate) },
            onDataChannelOpen = { webRtcClient.sendScreenSize(screenWidth, screenHeight) }
        )

        signalingClient = SignalingClient(AppConfig.SIGNALING_URL, object : SignalingClient.Listener {
            override fun onPeerJoined() {
                // Controller has joined our code — start the offer/answer dance.
                webRtcClient.createPeerConnection()
                startCapture()
                webRtcClient.createOffer { sdp -> signalingClient.sendOffer(sdp) }
            }
            override fun onRemoteAnswer(sdp: SessionDescription) = webRtcClient.setRemoteDescription(sdp)
            override fun onRemoteIceCandidate(candidate: IceCandidate) = webRtcClient.addIceCandidate(candidate)
            override fun onConnectionError(message: String) { /* surface in notification/UI if desired */ }
        })
        signalingClient.connect(role = "host", code = sessionCode)

        return START_REDELIVER_INTENT
    }

    private fun startCapture() {
        val projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }
        val resultData = currentResultData ?: return
        screenCapturer = ScreenCapturerAndroid(resultData, projectionCallback)

        videoSource = webRtcClient.factoryForVideoSource().createVideoSource(/* isScreencast = */ true)
        surfaceTextureHelper = SurfaceTextureHelper.create("ScreenCaptureThread", eglBase.eglBaseContext)

        screenCapturer?.initialize(surfaceTextureHelper, applicationContext, videoSource!!.capturerObserver)
        screenCapturer?.startCapture(screenWidth, screenHeight, 30)

        val videoTrack = webRtcClient.factoryForVideoSource()
            .createVideoTrack("remotesupport-video", videoSource)
        webRtcClient.addLocalVideoTrack(videoTrack)
    }

    private fun dispatchToAccessibilityService(event: com.yapper.farhand.network.RemoteInputEvent) {
        val svc = RemoteAccessibilityService.instance ?: return
        when (event.type) {
            "tap" -> svc.performTap(event.x1, event.y1)
            "swipe" -> svc.performSwipe(event.x1, event.y1, event.x2, event.y2, 200)
            "global" -> when (event.globalAction) {
                "back" -> svc.performGlobalBack()
                "home" -> svc.performGlobalHome()
                "recents" -> svc.performGlobalRecents()
            }
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, HostActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, FarHandApp.CAPTURE_CHANNEL_ID)
            .setContentTitle(getString(R.string.capture_notification_title))
            .setContentText(getString(R.string.capture_notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setContentIntent(stopIntent)
            .build()
    }

    override fun onDestroy() {
        screenCapturer?.stopCapture()
        screenCapturer?.dispose()
        videoSource?.dispose()
        surfaceTextureHelper?.dispose()
        if (::webRtcClient.isInitialized) webRtcClient.close()
        if (::signalingClient.isInitialized) signalingClient.disconnect()
        if (::eglBase.isInitialized) eglBase.release()
        super.onDestroy()
    }
}
