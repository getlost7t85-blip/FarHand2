package com.yapper.farhand.network

import android.os.Handler
import android.os.Looper
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription
import java.net.URI

/**
 * WebSocket client for the signaling protocol described in
 * /server/README.md: connect with role+code, wait for "peer-joined", then
 * exchange offer/answer/ICE JSON messages verbatim with the paired peer.
 *
 * All callbacks are delivered on the main thread, since callers hand them
 * straight to WebRTC APIs (SessionDescription, IceCandidate) and UI/service
 * code that expects to run there.
 */
class SignalingClient(
    private val serverUrl: String, // e.g. "wss://your-server.example/ws"
    private val listener: Listener
) {
    interface Listener {
        fun onPeerJoined() {}
        fun onPeerLeft() {}
        fun onRemoteOffer(sdp: SessionDescription) {}
        fun onRemoteAnswer(sdp: SessionDescription) {}
        fun onRemoteIceCandidate(candidate: IceCandidate) {}
        fun onRemoteInput(event: RemoteInputEvent) {}
        fun onConnectionError(message: String) {}
    }

    private var client: WebSocketClient? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var lastRole: String? = null
    private var lastCode: String? = null
    private var intentionalDisconnect = false
    private var reconnectAttempts = 0
    private val maxReconnectAttempts = 3
    private val reconnectDelayMs = 2000L

    fun connect(role: String, code: String) {
        lastRole = role
        lastCode = code
        intentionalDisconnect = false
        reconnectAttempts = 0
        openSocket(role, code)
    }

    private fun openSocket(role: String, code: String) {
        val uri = URI("$serverUrl?role=$role&code=$code")
        client = object : WebSocketClient(uri) {
            override fun onOpen(handshakedata: ServerHandshake?) {
                reconnectAttempts = 0 // a successful (re)connect resets the counter
            }

            override fun onMessage(message: String?) {
                message ?: return
                handleMessage(message)
            }

            override fun onClose(code: Int, reason: String?, remote: Boolean) {
                if (intentionalDisconnect) return
                mainHandler.post { listener.onConnectionError("Disconnected: $reason") }
                maybeReconnect()
            }

            override fun onError(ex: Exception?) {
                mainHandler.post { listener.onConnectionError(ex?.message ?: "Unknown error") }
            }
        }
        client?.connect()
    }

    /**
     * An unexpected drop (network blip, server restart) retries a few times
     * with a fixed backoff before giving up — this only re-opens the
     * socket, which replays "peer-joined" once both sides are back, so the
     * WebRTC layer above re-negotiates from scratch rather than assuming
     * any stale SDP/ICE state survived the gap.
     */
    private fun maybeReconnect() {
        val role = lastRole ?: return
        val code = lastCode ?: return
        if (reconnectAttempts >= maxReconnectAttempts) {
            mainHandler.post { listener.onConnectionError("Could not reconnect after $maxReconnectAttempts attempts") }
            return
        }
        reconnectAttempts++
        mainHandler.postDelayed({
            if (!intentionalDisconnect) openSocket(role, code)
        }, reconnectDelayMs)
    }

    private fun handleMessage(raw: String) {
        val json = try {
            JSONObject(raw)
        } catch (e: Exception) {
            return
        }
        when (json.optString("type")) {
            "peer-joined" -> mainHandler.post { listener.onPeerJoined() }
            "peer-left" -> mainHandler.post { listener.onPeerLeft() }
            "offer" -> mainHandler.post {
                listener.onRemoteOffer(
                    SessionDescription(SessionDescription.Type.OFFER, json.getString("sdp"))
                )
            }
            "answer" -> mainHandler.post {
                listener.onRemoteAnswer(
                    SessionDescription(SessionDescription.Type.ANSWER, json.getString("sdp"))
                )
            }
            "ice-candidate" -> mainHandler.post {
                listener.onRemoteIceCandidate(
                    IceCandidate(
                        json.getString("sdpMid"),
                        json.getInt("sdpMLineIndex"),
                        json.getString("candidate")
                    )
                )
            }
            "input" -> mainHandler.post {
                listener.onRemoteInput(
                    RemoteInputEvent(
                        type = json.getString("inputType"),
                        x1 = json.optDouble("x1", 0.0).toFloat(),
                        y1 = json.optDouble("y1", 0.0).toFloat(),
                        x2 = json.optDouble("x2", 0.0).toFloat(),
                        y2 = json.optDouble("y2", 0.0).toFloat(),
                        text = json.optString("text", null),
                        globalAction = json.optString("globalAction", null)
                    )
                )
            }
        }
    }

    fun sendOffer(sdp: SessionDescription) =
        send(JSONObject().put("type", "offer").put("sdp", sdp.description))

    fun sendAnswer(sdp: SessionDescription) =
        send(JSONObject().put("type", "answer").put("sdp", sdp.description))

    fun sendIceCandidate(candidate: IceCandidate) =
        send(
            JSONObject()
                .put("type", "ice-candidate")
                .put("sdpMid", candidate.sdpMid)
                .put("sdpMLineIndex", candidate.sdpMLineIndex)
                .put("candidate", candidate.sdp)
        )

    /** Sent as a signaling-channel fallback; prefer the WebRTC DataChannel when it's open. */
    fun sendInput(event: RemoteInputEvent) =
        send(
            JSONObject()
                .put("type", "input")
                .put("inputType", event.type)
                .put("x1", event.x1).put("y1", event.y1)
                .put("x2", event.x2).put("y2", event.y2)
                .apply {
                    event.text?.let { put("text", it) }
                    event.globalAction?.let { put("globalAction", it) }
                }
        )

    private fun send(json: JSONObject) {
        client?.takeIf { it.isOpen }?.send(json.toString())
    }

    fun disconnect() {
        intentionalDisconnect = true
        client?.close()
        client = null
    }
}

data class RemoteInputEvent(
    val type: String, // "tap" | "swipe" | "text" | "global"
    val x1: Float = 0f, val y1: Float = 0f,
    val x2: Float = 0f, val y2: Float = 0f,
    val text: String? = null,
    val globalAction: String? = null
)
