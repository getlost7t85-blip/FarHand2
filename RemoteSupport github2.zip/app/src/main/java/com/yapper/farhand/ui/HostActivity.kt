package com.yapper.farhand.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.yapper.farhand.R
import com.yapper.farhand.service.ScreenCaptureService
import kotlin.random.Random

/**
 * Host-side flow (the device being controlled/viewed). Mirrors RustDesk's
 * host app:
 *  1. Generate + show a pairing code the host shares with the controller
 *     out-of-band (call, chat) — that act of sharing is the actual consent
 *     step, same as RustDesk/AnyDesk.
 *  2. Ask for the two Android-mandated permissions (screen capture,
 *     accessibility) via their system dialogs — these cannot be granted
 *     silently/programmatically, by design.
 *  3. Optionally ask for "display over other apps" for the end-session pill.
 *  4. Start ScreenCaptureService, a foreground service that carries
 *     Android's own ongoing notification + capture icon the whole time.
 */
class HostActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private val sessionCode: String = (100000..999999).random().toString()

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                ContextCompat.startForegroundService(
                    this,
                    ScreenCaptureService.newIntent(this, result.resultCode, result.data!!, sessionCode)
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_host)

        projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        findViewById<android.widget.TextView>(R.id.tvSessionCode).text =
            getString(R.string.session_code_label, sessionCode)

        findViewById<android.widget.Button>(R.id.btnStartSharing).setOnClickListener {
            requestScreenCapture()
        }

        findViewById<android.widget.Button>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<android.widget.Button>(R.id.btnOverlayPermission).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                !Settings.canDrawOverlays(this)
            ) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
    }

    private fun requestScreenCapture() {
        // Launches Android's own system dialog: "RemoteSupport wants to
        // start capturing everything on your screen." There is no API to
        // skip or auto-dismiss this — it's the user's explicit go-ahead for
        // the session, same as in RustDesk/AnyDesk/TeamViewer.
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}

private fun IntRange.random(): Int = Random.nextInt(first, last + 1)
