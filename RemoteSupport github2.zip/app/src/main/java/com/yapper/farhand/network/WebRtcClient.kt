package com.yapper.farhand.network

import android.content.Context
import org.json.JSONObject
import org.webrtc.*
import java.nio.charset.Charset

/** Optional TURN credentials for peers behind symmetric NATs. Leave url blank to skip. */
data class TurnConfig(
    val url: String = "",
    val username: String = "",
    val password: String = ""
)

/**
 * Thin wrapper around a single org.webrtc.PeerConnection, shared by both
 * roles:
 *  - Host: adds a local screen-capture video track (see ScreenCaptureService,
 *    which uses org.webrtc.ScreenCapturerAndroid) and creates the offer;
 *    also creates the "input" DataChannel, and once it opens, sends the
 *    device's real screen size down it so the controller can map touch
 *    coordinates correctly.
 *  - Controller: has no local video; receives the remote video track and
 *    forwards it to a sink (e.g. SurfaceViewRenderer); receives the
 *    DataChannel the host created, reads the screen-size message off it,
 *    and uses it to send input events (taps and swipes) back.
 *
 * SDP/ICE exchange is delegated to the caller via callbacks so this class
 * doesn't need to know about SignalingClient.
 */
class WebRtcClient(
    context: Context,
    private val isHost: Boolean,
    private val eglBase: EglBase,
    private val turnConfig: TurnConfig = TurnConfig(),
    private val onRemoteVideoTrack: (VideoTrack) -> Unit = {},
    private val onInputEvent: (RemoteInputEvent) -> Unit = {},
    private val onScreenSize: (width: Int, height: Int) -> Unit = { _, _ -> },
    private val onLocalIceCandidate: (IceCandidate) -> Unit = {},
    private val onDataChannelOpen: () -> Unit = {},
) {
    private val factory: PeerConnectionFactory
    var peerConnection: PeerConnection? = null
        private set
    private var dataChannel: DataChannel? = null

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .createInitializationOptions()
        )
        val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()
    }

    fun factoryForVideoSource(): PeerConnectionFactory = factory

    fun createPeerConnection() {
        val iceServers = buildList {
            add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            if (turnConfig.url.isNotBlank()) {
                add(
                    PeerConnection.IceServer.builder(turnConfig.url)
                        .setUsername(turnConfig.username)
                        .setPassword(turnConfig.password)
                        .createIceServer()
                )
            }
        }
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }

        peerConnection = factory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) = onLocalIceCandidate(candidate)
            override fun onTrack(transceiver: RtpTransceiver) {
                val track = transceiver.receiver.track()
                if (track is VideoTrack) onRemoteVideoTrack(track)
            }
            override fun onDataChannel(channel: DataChannel) {
                // Controller side: host created the channel, we just observe it.
                dataChannel = channel
                observeDataChannel(channel)
            }
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {}
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState?) {}
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {}
            override fun onRemoveStream(stream: MediaStream?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
        })

        if (isHost) {
            dataChannel = peerConnection?.createDataChannel("input", DataChannel.Init())
            dataChannel?.let { observeDataChannel(it) }
        }
    }

    fun addLocalVideoTrack(track: VideoTrack) {
        peerConnection?.addTrack(track, listOf("remotesupport-stream"))
    }

    fun createOffer(onCreated: (SessionDescription) -> Unit) {
        val constraints = MediaConstraints()
        peerConnection?.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(sdp: SessionDescription) {
                peerConnection?.setLocalDescription(SdpObserverAdapter(), sdp)
                onCreated(sdp)
            }
        }, constraints)
    }

    fun createAnswer(onCreated: (SessionDescription) -> Unit) {
        val constraints = MediaConstraints()
        peerConnection?.createAnswer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(sdp: SessionDescription) {
                peerConnection?.setLocalDescription(SdpObserverAdapter(), sdp)
                onCreated(sdp)
            }
        }, constraints)
    }

    fun setRemoteDescription(sdp: SessionDescription) {
        peerConnection?.setRemoteDescription(SdpObserverAdapter(), sdp)
    }

    fun addIceCandidate(candidate: IceCandidate) {
        peerConnection?.addIceCandidate(candidate)
    }

    /** Controller -> host, over the DataChannel the host created. */
    fun sendInput(event: RemoteInputEvent) {
        val json = JSONObject()
            .put("kind", "input")
            .put("inputType", event.type)
            .put("x1", event.x1).put("y1", event.y1)
            .put("x2", event.x2).put("y2", event.y2)
            .apply {
                event.text?.let { put("text", it) }
                event.globalAction?.let { put("globalAction", it) }
            }
        sendRaw(json)
    }

    /** Host -> controller, sent once the DataChannel opens (see onDataChannelOpen). */
    fun sendScreenSize(width: Int, height: Int) {
        sendRaw(JSONObject().put("kind", "screen-size").put("width", width).put("height", height))
    }

    private fun sendRaw(json: JSONObject) {
        val bytes = json.toString().toByteArray(Charset.forName("UTF-8"))
        dataChannel?.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap(bytes), false))
    }

    private fun observeDataChannel(channel: DataChannel) {
        channel.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previousAmount: Long) {}
            override fun onStateChange() {
                if (channel.state() == DataChannel.State.OPEN) onDataChannelOpen()
            }
            override fun onMessage(buffer: DataChannel.Buffer) {
                val bytes = ByteArray(buffer.data.remaining())
                buffer.data.get(bytes)
                val json = try {
                    JSONObject(String(bytes, Charset.forName("UTF-8")))
                } catch (e: Exception) {
                    return
                }
                when (json.optString("kind")) {
                    "screen-size" -> onScreenSize(json.optInt("width"), json.optInt("height"))
                    "input", "" -> onInputEvent(
                        RemoteInputEvent(
                            type = json.getString("inputType"),
                            x1 = json.optDouble("x1", 0.0).toFloat(),
                            y1 = json.optDouble("y1", 0.0).toFloat(),
                            x2 = json.optDouble("x2", 0.0).toFloat(),
                            y2 = json.optDouble("y2", 0.0).toFloat(),
                            text = json.optString("text", null),
                            globalAction = json.optString("globalAction", null)
                        )
                    )
                }
            }
        })
    }

    fun close() {
        dataChannel?.close()
        peerConnection?.close()
        peerConnection?.dispose()
    }
}

private open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(sdp: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}
