package com.yapper.farhand.ui

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.yapper.farhand.R

/**
 * A small floating pill reading "Session active · tap to end", requiring
 * the "display over other apps" permission. This is an EXTRA, friendlier
 * way for the host to end a session — it sits alongside, not instead of,
 * the mandatory foreground-service notification and system capture icon.
 * It never replaces them and it isn't rendered without the notification
 * also being present, because the service that would show it can't start
 * without that notification already up.
 */
class SessionPillOverlay(private val context: Context, private val onTapEnd: () -> Unit) {

    private var windowManager: WindowManager? = null
    private var pillView: TextView? = null

    fun show() {
        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 60
        }

        val pillBackground = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 48f
            setColor(ContextCompat.getColor(context, R.color.brand_primary_variant))
            setStroke(2, ContextCompat.getColor(context, R.color.brand_accent))
        }

        pillView = TextView(context).apply {
            text = context.getString(R.string.pill_text)
            background = pillBackground
            setTextColor(ContextCompat.getColor(context, R.color.brand_on_primary))
            setPadding(36, 18, 36, 18)
            setOnClickListener { onTapEnd() }
        }

        windowManager?.addView(pillView, params)
    }

    fun hide() {
        pillView?.let { windowManager?.removeView(it) }
        pillView = null
    }
}
